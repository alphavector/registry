.. automodule:: graph_tool.draw
   :members:
   :undoc-members:
   :show-inheritance:
