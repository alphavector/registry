.. automodule:: graph_tool.generation
   :members:
   :undoc-members:
