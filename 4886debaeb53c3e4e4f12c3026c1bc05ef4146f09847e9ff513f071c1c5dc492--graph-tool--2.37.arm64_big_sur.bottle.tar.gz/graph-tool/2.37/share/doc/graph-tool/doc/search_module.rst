.. automodule:: graph_tool.search
   :members:
   :undoc-members:
