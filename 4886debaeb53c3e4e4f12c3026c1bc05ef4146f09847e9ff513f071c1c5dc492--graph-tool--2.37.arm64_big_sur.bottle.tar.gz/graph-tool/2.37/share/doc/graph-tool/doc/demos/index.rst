Cookbook
========

Contents:

.. toctree::
   :maxdepth: 3
   :glob:

   inference/inference
   animation/animation
   matplotlib/matplotlib
   cppextensions/cppextensions