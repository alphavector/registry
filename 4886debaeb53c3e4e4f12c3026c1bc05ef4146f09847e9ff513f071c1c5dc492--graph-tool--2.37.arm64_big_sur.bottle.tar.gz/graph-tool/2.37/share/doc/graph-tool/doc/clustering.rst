.. automodule:: graph_tool.clustering
   :members:
   :undoc-members:
