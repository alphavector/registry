.. automodule:: graph_tool.util
   :members:
   :undoc-members:
